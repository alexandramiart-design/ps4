Place your own verified web-host files in this folder before building: index.html, JavaScript, CSS and compatible support files. No jailbreak payload is included in this starter project.
