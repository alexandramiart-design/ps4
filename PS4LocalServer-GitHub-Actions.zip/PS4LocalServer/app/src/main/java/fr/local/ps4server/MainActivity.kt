package fr.local.ps4server

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.ClipboardManager
import android.content.ClipData
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var address: TextView
    private lateinit var terminalPanel: LinearLayout
    private lateinit var output: TextView
    private lateinit var command: EditText
    private var requestedRunning = false
    private var terminalVisible = false
    private val port = ServerService.PORT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 16)
            setBackgroundColor(0xFF0B0E13.toInt())
        }
        fun text(value: String, size: Float, color: Int = 0xFFE5EAF2.toInt()) =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                setPadding(0, 7, 0, 7)
            }

        root.addView(text("PS4 LOCAL SERVER", 23f))
        root.addView(text("AfterGlow • Hôte HTTP local", 13f, 0xFF91A0B5.toInt()))
        status = text("● Serveur arrêté", 17f, 0xFFFFC36B.toInt())
        root.addView(status)
        address = text("Adresse PS4 : —", 15f)
        root.addView(address)
        val copy = Button(this).apply {
            text = "COPIER L’ADRESSE"
            setOnClickListener {
                val url = serverUrl()
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("URL PS4", url))
                append("Adresse copiée : $url")
            }
        }
        root.addView(copy)

        terminalPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        terminalPanel.addView(text("TERMINAL DE GESTION", 17f))
        output = text("PS4 Local Server\nTape help pour afficher les commandes.", 12f, 0xFFB7C8DD.toInt())
        val logScroll = ScrollView(this).apply {
            addView(output)
        }
        terminalPanel.addView(logScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        command = EditText(this).apply {
            hint = "Commande : help, status, ip, files, update…"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF91A0B5.toInt())
            singleLine = true
        }
        val commandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(command, LinearLayout.LayoutParams(0, -2, 1f))
            addView(Button(this@MainActivity).apply {
                text = "OK"
                setOnClickListener { executeCommand() }
            })
        }
        terminalPanel.addView(commandRow)
        root.addView(terminalPanel, LinearLayout.LayoutParams(-1, 0, 1f))

        val spacer = Space(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        bottom.addView(Button(this).apply {
            text = "TERMINAL"
            setOnClickListener {
                terminalVisible = !terminalVisible
                terminalPanel.visibility = if (terminalVisible) View.VISIBLE else View.GONE
                if (terminalVisible) command.requestFocus()
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(Button(this).apply {
            text = "SERVEUR ON / OFF"
            setOnClickListener { toggleServer() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bottom)
        setContentView(root)
    }

    private fun toggleServer() {
        if (requestedRunning) {
            stopService(Intent(this, ServerService::class.java))
            requestedRunning = false
            append("Arrêt du serveur demandé.")
        } else {
            startForegroundService(Intent(this, ServerService::class.java).setAction("START"))
            requestedRunning = true
            append("Démarrage demandé sur le port $port.")
        }
        refresh()
    }

    private fun executeCommand() {
        val raw = command.text.toString().trim()
        val parts = raw.split(Regex("\\s+"), limit = 2)
        val c = parts.firstOrNull()?.lowercase() ?: ""
        val response = when (c) {
            "help" -> "Commandes : help, status, ip, url, files, start, stop, update, clear"
            "status" -> if (requestedRunning) "Démarrage demandé. URL : ${serverUrl()}" else "Serveur arrêté."
            "ip" -> "Adresse locale : ${localIp()}:$port"
            "url" -> serverUrl()
            "files" -> "Site embarqué : AfterGlow 14.00 (dossier ps4-goldhen1400). ${assetFiles().size} fichiers web/ressources intégrés."
            "start" -> {
                if (!requestedRunning) {
                    startForegroundService(Intent(this, ServerService::class.java).setAction("START"))
                    requestedRunning = true
                }
                "Démarrage demandé."
            }
            "stop" -> {
                stopService(Intent(this, ServerService::class.java))
                requestedRunning = false
                "Arrêt demandé."
            }
            "update" -> {
                startForegroundService(Intent(this, ServerService::class.java).setAction(ServerService.ACTION_REFRESH))
                requestedRunning = true
                "Rafraîchissement demandé : les fichiers intégrés vont remplacer la copie locale. Le serveur redémarre."
            }
            "clear" -> { output.text = ""; "" }
            "" -> ""
            else -> "Commande inconnue. Tape help."
        }
        if (c != "clear" && response.isNotEmpty()) append("> $raw\n$response")
        command.setText("")
        refresh()
    }

    private fun assetFiles(): List<String> {
        val result = mutableListOf<String>()
        fun walk(path: String) {
            assets.list(path)?.forEach { name ->
                val child = "$path/$name"
                if ((assets.list(child)?.isNotEmpty()) == true) walk(child) else result.add(child)
            }
        }
        walk("site")
        return result
    }

    private fun append(message: String) {
        if (::output.isInitialized) output.append("\n\n$message")
    }

    private fun refresh() {
        if (::status.isInitialized) {
            status.text = if (requestedRunning) "● Serveur démarrage demandé" else "● Serveur arrêté"
            status.setTextColor(if (requestedRunning) 0xFF7FD0A0.toInt() else 0xFFFFC36B.toInt())
            address.text = "Adresse PS4 : ${serverUrl()}"
        }
    }

    private fun serverUrl() = "http://${localIp()}:$port/"

    private fun localIp(): String = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress && it.isSiteLocalAddress }
            ?.hostAddress ?: "IP indisponible"
    } catch (_: Exception) { "IP indisponible" }
}
