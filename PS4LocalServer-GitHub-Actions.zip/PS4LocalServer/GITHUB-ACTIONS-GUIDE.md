# Compiler l'APK avec GitHub Actions

Le workflow `.github/workflows/android-apk.yml` compile automatiquement une APK debug sur les serveurs GitHub.

## Installation dans le dépôt GitHub

1. Décompresser cette archive.
2. Dans le dépôt GitHub, ouvrir **Add file → Upload files**.
3. Envoyer le contenu du dossier `PS4LocalServer` à la racine du dépôt (y compris le dossier caché `.github`).
4. Valider avec **Commit changes**.
5. Ouvrir l'onglet **Actions**, sélectionner **Build Android APK**, puis **Run workflow** si le workflow ne s'est pas lancé automatiquement.
6. Attendre la fin du job, ouvrir son exécution réussie, puis télécharger l'artefact **PS4LocalServer-debug-apk** dans la section Artifacts.

Aucun Personal Access Token n'est nécessaire pour cette méthode. GitHub Actions utilise les permissions du workflow.

## Résultat

L'artefact contient l'APK debug générée à `app/build/outputs/apk/debug/app-debug.apk`.

Cette APK est une build de test non signée pour distribution Play Store. Il faut l'installer manuellement sur Android et autoriser l'installation depuis la source utilisée.

## Important

La réussite de la compilation ne valide pas la compatibilité de l'exploit PS4 ni le fonctionnement du payload. Tester avec prudence. Le projet indique lui-même que `afterglow.js` n'a pas été testé dans cet hébergement.
