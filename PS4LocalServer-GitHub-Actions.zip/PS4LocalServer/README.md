# PS4 Local Server — projet Android

Cette version intègre le contenu web du dossier `ps4-goldhen1400` fourni dans `ps4.zip`, dans `app/src/main/assets/site/`. Le dossier `ps4-akatsuki-jailbreak` reste séparé et n'est pas mélangé au site 14.00.

## Fonctions présentes
- Serveur HTTP local sur le port `8000`, démarré/arrêté depuis l'application.
- Affichage de l'adresse IPv4 et copie de l'URL à saisir dans le navigateur PS4.
- Terminal de gestion limité : `help`, `status`, `ip`, `url`, `files`, `start`, `stop`, `update`, `clear`.
- `update` remplace la copie locale par les fichiers web embarqués dans l'APK.
- Types MIME adaptés aux modules JavaScript et fichiers `.bin` / `.iso`.
- En-têtes `no-store` sur les scripts et payloads, conformément au `serve.sh` fourni.
- Les fichiers sont servis localement : pas besoin d'Internet après installation.

## Construire l'APK
1. Ouvrir ce dossier dans Android Studio.
2. Laisser Gradle synchroniser les dépendances (Internet requis la première fois).
3. Choisir **Build > Build APK(s)**.
4. Installer l'APK debug générée sur le téléphone.
5. Mettre le téléphone et la PS4 sur le même réseau Wi-Fi, démarrer le serveur, puis saisir l'URL affichée dans le navigateur PS4.

## Limites et vérifications indispensables
- Ceci est un projet source Android, pas encore une APK compilée ou testée sur le téléphone.
- Le terminal est une console de commandes de l'application, pas un shell Android/Linux général.
- `update` restaure les fichiers fournis avec l'APK ; une fonction d'import de nouvelles versions depuis ZIP n'est pas encore intégrée.
- Le dossier `ps4-goldhen1400` contient des indications contradictoires : son README présente AfterGlow comme ciblant le firmware 14.00, mais son `index.html` affiche « 14.02 ». Vérifier la compatibilité exacte avant toute exécution.
- Le fichier `afterglow.js` fourni contient la mention « UNTESTED IN THIS HOST ». L'hébergement HTTP réussi ne prouve ni la compatibilité de l'exploit, ni le chargement de GoldHEN. Une tentative d'exploit peut provoquer un plantage ou un redémarrage de la console.
- Les fichiers d'origine de `ps4.zip` ne sont pas modifiés. Le projet Android embarque une copie du seul dossier `ps4-goldhen1400`, sans son historique `.git`.
